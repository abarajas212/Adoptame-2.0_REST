<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

//$app = new \SLIM\App;

use \PHPMailer\PHPMailer\PHPMailer;
use \PHPMailer\PHPMailer\PSMTP;
use \PHPMailer\PHPMailer\Exception;


//-------------------------------------------------------------------------
//Obtener todos los usuarios
//-------------------------------------------------------------------------
$app->get('/api/clientes',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	$consulta = 'SELECT * FROM usuario';

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$clientes = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($clientes);

		//Hago un echo a la funcion que se ejecutara en javascript para devolver la respuesta
		//echo "myFunc(".json_encode($clientes).")";
		//echo $_GET['callback']."(".json_encode($arr).");";


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//---------------------------------------------------------------------------------
//Comprobar que el codigo introducido pertenece a una protectora
//---------------------------------------------------------------------------------
$app->get('/api/cliente/comprobarCodigo/{idProtectora}/{codigo}',function(Request $request, Response $response){

	$idProtectora = $request->getAttribute('idProtectora');
	$codigo = $request->getAttribute('codigo');

	$consulta = "SELECT * FROM codigosProtectora WHERE idProtectora = '$idProtectora' AND codigo = '$codigo'";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$protectoraCodigo = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;
		$db = new db();

		//Exportar y mostrar JSON
		//header('Content-type: application/json; charset=utf-8');
		echo json_encode($protectoraCodigo);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}


});

//----------------------------------------------------------------------------------------------
//Dar de alta a un usuario en una protectora
//---------------------------------------------------------------------------------------------
$app->post('/api/cliente/hacerColaborador',function(Request $request, Response $response){

	$idProtectora = $request->getParam('idProtectora');
	$idUsuario = $request->getParam('idUsuario');

	$consulta = "UPDATE usuario SET idProtectora = :idProtectora WHERE idUsuario = :idUsuario";
	
	try{

		$db = new db();

		//Conexion

		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idProtectora', $idProtectora);
		$stmt->bindParam(':idUsuario', $idUsuario);
		$stmt->execute();

		echo '{"notice": {"text": "El usuario es ahora colaborador"}';

	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}
	

});

//-------------------------------------------------------------------------
//Obtener un usuario
//-------------------------------------------------------------------------
$app->get('/api/cliente/{id}',function(Request $request, Response $response){

	$id = $request->getAttribute('id');

	$consulta = "SELECT * FROM usuario WHERE idUsuario='$id'";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$cliente = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		//header('Content-type: application/json; charset=utf-8');
		echo json_encode($cliente);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//------------------------------------------------------------------------------------------
//Obtener autenticacion usuario
//-------------------------------------------------------------------------------------------
$app->get('/api/cliente/autenticacion/{id}',function(Request $request, Response $response){

	$id = $request->getAttribute('id');
	$password = $request->getAttribute('password');

	$consulta = "SELECT * FROM usuario WHERE id='$id'";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$cliente = $ejecutar->fetch(PDO::FETCH_OBJ);
		$db = null;

		
		$contrass = $cliente->password;

		$autenticacion = new StdClass;
		$autenticacion->password = $cliente->password;
		
		//Exportar y mostrar JSON
		//header('Content-type: application/json; charset=utf-8');
		echo json_encode($autenticacion);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//---------------------------------------------------------------------------
//Obtener ciudad de un usuario
//----------------------------------------------------------------------------
$app->get('/api/ciudad/{user}',function(Request $request, Response $response){

	$user = $request->getAttribute('user');

	$consulta = "SELECT ciudad FROM perfil WHERE idUsuario='$user'";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$cliente = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		//header('Content-type: application/json; charset=utf-8');
		echo json_encode($cliente);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//---------------------------------------------------------------------------------
//Agregar un cliente
//---------------------------------------------------------------------------------
$app->post('/api/cliente/agregar',function(Request $request, Response $response){

	$idUsuario = $request->getParam('idUsuario');
	$password = $request->getParam('password');
	$nombre = $request->getParam('nombre');
	$apellidos = $request->getParam('apellidos');
	$email = $request->getParam('email');
	$telefono = $request->getParam('telefono');
	$consulta = "INSERT INTO usuario (idUsuario, password, nombre, apellidos, email, telefono)VALUES(:idUsuario, :password, :nombre, :apellidos, :email, :telefono)";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idUsuario', $idUsuario);
		$stmt->bindParam(':password', $password);
		$stmt->bindParam(':nombre', $nombre);
		$stmt->bindParam(':apellidos', $apellidos);
		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':telefono', $telefono);
		$stmt->execute();
		echo '{"success": {"text": "Cliente agregado"}';
		
	}catch(PDOException $e){
		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//---------------------------------------------------------------------------
// Comprobar usuario o email para recuperar contraseña
//----------------------------------------------------------------------------
$app->get('/api/cliente/comprobarRecuperacion/{idUsuario}/{email}',function(Request $request, Response $response){

	$idUsuario = $request->getAttribute('idUsuario');
	$email = $request->getAttribute('email');

	$consulta = "SELECT idUsuario FROM usuario WHERE idUsuario='$idUsuario' AND email='$email'";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$cliente = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		//header('Content-type: application/json; charset=utf-8');
		echo json_encode($cliente);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//---------------------------------------------------------------------------------
// Modificar contraseña usuario
//---------------------------------------------------------------------------------
$app->post('/api/cliente/modificarContrasenia',function(Request $request, Response $response){

	$idUsuario = $request->getParam('idUsuario');
	$password = $request->getParam('password');

	$consulta = "UPDATE usuario SET password = :password WHERE idUsuario = :idUsuario";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idUsuario', $idUsuario);
		$stmt->bindParam(':password', $password);
		$stmt->execute();
		echo '{"success": {"text": "contraseñaña modificada"}';
		
	}catch(PDOException $e){
		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});


// Envio email contacto
//--------------------------------------------------------------------------------------------------------
$app->post('/api/cliente/enviarEmail/modificarContrasenia',function(Request $request, Response $response){

	$emailUsuario = $request->getParam('emailUsuario');
	$asunto = $request->getParam('asunto');
	$idUsuario = $request->getParam('idUsuario');
	$password = $request->getParam('password');

	//Datos email de la aplicacion
	$email_user = "adoptame2.0@gmail.com";
	$email_password = "Adoptame20usal";
	//Asunto
	$the_subject = "Recuperar contraseña";
	
	$address_to = "adoptame2.0@gmail.com";
	$from_name = "Adoptame 2.0";
	$phpmailer = new PHPMailer();
// ---------- datos de la cuenta de Gmail -------------------------------------------------------------
	$phpmailer->Username = $email_user;
	$phpmailer->Password = $email_password; 
//----------------------------------------------------------------------------------------------------
// $phpmailer->SMTPDebug = 1;
	$phpmailer->SMTPSecure = 'ssl';
	$phpmailer->Host = "smtp.gmail.com"; // GMail
	$phpmailer->Port = 465;
	$phpmailer->IsSMTP(); // use SMTP
	$phpmailer->SMTPAuth = true;
	$phpmailer->setFrom($phpmailer->Username,$from_name);
	//Usuario en reply
	//$phpmailer->AddReplyTo($emailUsuario, $nombreUsuario);

	$phpmailer->AddAddress($emailUsuario); // recipients email
	$phpmailer->Subject = $asunto;	
	$phpmailer->Body .= "<p>Hola!</p>";
	$phpmailer->Body .= "<p>Has solicitado un cambio de contraseña</p>";
	$phpmailer->Body .= "<p>Tu nueva contraseña para el usuario $idUsuario es:</p>";
	$phpmailer->Body .= "<p style='color:#3498db;'>$password </p>";
	$phpmailer->Body .= "<p>No olvides modificarla lo antes posible en la aplicación</p>";
	$phpmailer->Body .="<h1 style='color:#3498db;'>Adoptame 2.0</h1>";
	$phpmailer->AddEmbeddedImage('../iconos/logo.png', 'logoimg', 'logo.jpg');
	$phpmailer->Body .="<p><img src=\"cid:logoimg\" /></p>";
	$phpmailer->Body .= "<p>Fecha y Hora: ".date("d-m-Y h:i:s")."</p>";
	$phpmailer->IsHTML(true);
	$phpmailer -> charSet = "UTF-8"; 
	
	if(!$phpmailer->Send()){
   		echo "Error en el envio: " . $phpmailer->ErrorInfo;;
	}else{
   		echo "Email enviado";
	}

});



?>