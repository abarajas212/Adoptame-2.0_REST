<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

use \PHPMailer\PHPMailer\PHPMailer;
use \PHPMailer\PHPMailer\PSMTP;
use \PHPMailer\PHPMailer\Exception;

require '../vendor/phpmailer/phpmailer/src/PHPMailer.php';
require '../vendor/phpmailer/phpmailer/src/SMTP.php';

//$app = new \SLIM\App;

//-------------------------------------------------------------------------
//Obtener todos los datos de la protectora
//-------------------------------------------------------------------------
$app->get('/api/protectora/{idProtectora}',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	$idProtectora = $request->getAttribute('idProtectora');

	$consulta = "SELECT * FROM protectora WHERE idProtectora='$idProtectora'";

	try{

		$db = new db();

		//Conexion

		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$protectoras = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($protectoras);

	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//----------------------------------------------------------------------------------------------
//Generar codigo de la protectora
//Debe ser un metodo post para insertar en bbdd, por ahora queda asi para probar
//----------------------------------------------------------------------------------------------
$app->post('/api/protectora/modificarCodigoProtectora',function(Request $request, Response $response){

	$idProtectora = $request->getParam('idProtectora');

	$key = '';
	$longitud = 25; 
	$pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$max = strlen($pattern)-1;
	for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};

	$consulta = "UPDATE codigosProtectora SET codigo = :key WHERE idProtectora = :idProtectora";
	
	try{

		$db = new db();

		//Conexion

		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idProtectora', $idProtectora);
		$stmt->bindParam(':key', $key);
		$stmt->execute();

		echo '{"notice": {"text": "Codigo modificado"}';

	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}
	

});

//----------------------------------------------------------------------------------------------
//Insertar codigo de la protectora
//Debe ser un metodo post para insertar en bbdd, por ahora queda asi para probar
//----------------------------------------------------------------------------------------------
$app->post('/api/protectora/insertarCodigoProtectora',function(Request $request, Response $response){

	$idProtectora = $request->getParam('idProtectora');

	$codigo = '';
	$longitud = 25; 
	$pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$max = strlen($pattern)-1;
	for($i=0;$i < $longitud;$i++) $codigo .= $pattern{mt_rand(0,$max)};

	$consulta = "INSERT INTO codigosProtectora (idProtectora, codigo) VALUES (:idProtectora, :codigo)";
	
	try{

		$db = new db();

		//Conexion

		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idProtectora', $idProtectora);
		$stmt->bindParam(':codigo', $codigo);
		$stmt->execute();

		echo '{"notice": {"text": "Codigo insertado"}';

	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}
	

});
//----------------------------------------------------------------------------------------------
//Obtener codigo protectora
//----------------------------------------------------------------------------------------------
$app->get('/api/protectora/obtenerCodigoProtectora/{idProtectora}',
			function(Request $request, Response $response){

	$idProtectora = $request->getAttribute('idProtectora');

	$consulta = "SELECT codigo as codigo FROM codigosProtectora WHERE idProtectora='$idProtectora'";
					
	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$codigo = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		//header('Content-type: application/json; charset=utf-8');
		echo json_encode($codigo);

	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

	
});

//--------------------------------------------------------------------------------------
//Agregar un animal
//--------------------------------------------------------------------------------------
$app->post('/api/protectora/agregar',function( $request,  $response){

	$idProtectora = $request->getParam('idProtectora');
    $especie = $request->getParam('especie');
    $sexo= $request->getParam('sexo');
    $tamanio = $request->getParam('tamanio');
    $estado = $request->getParam('estado');
    $nombre = $request->getParam('nombre');
    $descripcion = $request->getParam('descripcion');
    $apego = $request->getParam('apego');
    $obediencia = $request->getParam('obediencia');
    $comportamiento = $request->getParam('comportamiento');
    $actividad = $request->getParam('actividad');
    $fecha_ingreso = $request->getParam('fecha_ingreso');

// idAnimal se rellena solo
	$consulta = "INSERT INTO animal (idProtectora, especie, sexo, tamanio, estado, nombre, descripcion, apego, obediencia, comportamiento, actividad, fecha_ingreso) VALUES (:idProtectora, :especie, :sexo, :tamanio, :estado, :nombre, :descripcion, :apego, :obediencia, :comportamiento, :actividad, :fecha_ingreso)";

	try{

		$db = new db();

		//Conexion

		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idProtectora', $idProtectora);
		$stmt->bindParam(':especie', $especie);
		$stmt->bindParam(':sexo', $sexo);
		$stmt->bindParam(':tamanio', $tamanio);
		$stmt->bindParam(':estado', $estado);
		$stmt->bindParam(':nombre', $nombre);
		$stmt->bindParam(':descripcion', $descripcion);
		$stmt->bindParam(':apego', $apego);
		$stmt->bindParam(':obediencia', $obediencia);
		$stmt->bindParam(':comportamiento', $comportamiento);
		$stmt->bindParam(':actividad', $actividad);
		$stmt->bindParam(':fecha_ingreso', $fecha_ingreso);
		$stmt->execute();
		echo '{"notice": {"text": "Animal agregado"}';
		
	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});
//----------------------------------------------------------------------------------------------
//Obtener id de un animal ya subido
//----------------------------------------------------------------------------------------------
$app->get('/api/protectora/obtenerIdAnimal/{idProtectora}/{nombreAnimal}',
			function(Request $request, Response $response){

	$idProtectora = $request->getAttribute('idProtectora');
	$nombreAnimal = $request->getAttribute('nombreAnimal');

	$consulta = "SELECT (MAX(idAnimal)) as idAnimal FROM animal WHERE idProtectora='$idProtectora' 
					AND nombre='$nombreAnimal'";
					
	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$idAnimal = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		//header('Content-type: application/json; charset=utf-8');
		echo json_encode($idAnimal);

	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

	
});

//----------------------------------------------------------------------------------------------
//Insertar relacion foto animal
//----------------------------------------------------------------------------------------------
$app->post('/api/protectora/animalFoto',function( $request,  $response){

	$idAnimal = $request->getParam('idAnimal');
	$idFoto = $request->getParam('idFoto');
	
// idFoto
	$consulta = "INSERT INTO fotoAnimal (idAnimal, idFoto) VALUES(:idAnimal, :idFoto)";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idAnimal', $idAnimal);
		$stmt->bindParam(':idFoto', $idFoto);

		$stmt->execute();
		echo '{"notice": {"text": "Foto de animal agregada"}';

		
	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}
});

//----------------------------------------------------------------------------------------------
//Insertar relacion foto protectora
//----------------------------------------------------------------------------------------------
$app->post('/api/protectora/protectoraFoto',function( $request,  $response){

	$idProtectora = $request->getParam('idProtectora');
	$idFotoProtectora = $request->getParam('idFotoProtectora');
	
// idFoto
	$consulta = "INSERT INTO fotoprotectora (idProtectora, idFotoProtectora) VALUES(:idProtectora, :idFotoProtectora)";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idProtectora', $idProtectora);
		$stmt->bindParam(':idFotoProtectora', $idFotoProtectora);

		$stmt->execute();
		
		echo '{"notice": {"text": "Foto de protectora agregada"}';

		
	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}
});

//----------------------------------------------------------------------------------------------------------------
//Obtener datos email
//-----------------------------------------------------------------------------------------------------------------
$app->get('/api/protectora/obtenerDatoEmail/{idProtectora}',function(Request $request, Response $response){

	$idProtectora = $request->getAttribute('idProtectora');

	$consulta = "SELECT protectora.idProtectora as idProtectora, protectora.nombre as nombre,
					codigosprotectora.codigo as codigo
				FROM protectora INNER JOIN codigosprotectora ON protectora.idProtectora = codigosprotectora.idProtectora 
				WHERE protectora.idProtectora = '$idProtectora'";
					
	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$idAnimal = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		//header('Content-type: application/json; charset=utf-8');
		echo json_encode($idAnimal);

	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

	
});
//--------------------------------------------------------------------------------------
// Envio de emails
//--------------------------------------------------------------------------------------
$app->post('/api/protectora/enviarEmail/codigoProtectora',function(Request $request, Response $response){

	$idProtectora = $request->getParam('idProtectora');
	$codigo = $request->getParam('codigo');
	$nombreProtectora = $request->getParam('nombreProtectora');
	$address_to = $request->getParam('destinatario');


	//Datos email de la aplicacion
	$email_user = "adoptame2.0@gmail.com";
	$email_password = "Adoptame20usal";
	//Asunto
	$the_subject = "Codigo colaborador protectora";
	
	//$address_to = "adoptame2.0@gmail.com";
	$from_name = "Adoptame 2.0";
	$phpmailer = new PHPMailer();
// ---------- datos de la cuenta de Gmail -------------------------------
	$phpmailer->Username = $email_user;
	$phpmailer->Password = $email_password; 
//-----------------------------------------------------------------------
// $phpmailer->SMTPDebug = 1;
	$phpmailer->SMTPSecure = 'ssl';
	$phpmailer->Host = "smtp.gmail.com"; // GMail
	$phpmailer->Port = 465;
	$phpmailer->IsSMTP(); // use SMTP
	$phpmailer->SMTPAuth = true;
	$phpmailer->setFrom($phpmailer->Username,$from_name);
	$phpmailer->AddAddress($address_to); // recipients email
	$phpmailer->Subject = $the_subject;	
	$phpmailer->Body .="<h1 style='color:#3498db;'>Hola!</h1>";
	$phpmailer->Body .= "<p>La protectora <b>$nombreProtectora</b> ha decidido enviarle sus datos para que pueda unirse";
	$phpmailer->Body .= " a través de la aplicación y colaborar en sus tareas. </p>";
	$phpmailer->Body .= "<p>Desde adoptame te damos las gracias por invertir tu tiempo en ayudar a los peludos</p>";
	$phpmailer->Body .=" <p>Aquí tienes los datos de la protectora: <b>$nombreProtectora</b>:</p>";
	$phpmailer->Body .="<p><h2> Identificador de la protectora: </h2> $idProtectora </p>";
	$phpmailer->Body .="<p><h2> Código: </h2> $codigo </p>";
	$phpmailer->Body .="<h1 style='color:#3498db;'>Gracias!</h1>";
	$phpmailer->AddEmbeddedImage('../iconos/logo.png', 'logoimg', 'logo.jpg');
	$phpmailer->Body .="<p><img src=\"cid:logoimg\" /></p>";
	$phpmailer->Body .= "<p>Fecha y Hora: ".date("d-m-Y h:i:s")."</p>";
	$phpmailer->IsHTML(true);
	$phpmailer -> charSet = "UTF-8"; 
	//$phpmailer->Send();
	
	if(!$phpmailer->Send()){
   		echo "Error en el envio: " . $phpmailer->ErrorInfo;;
	}else{
   		echo "Email enviado";
	}

});

//--------------------------------------------------------------------------------------------------------
// Envio email contacto
//--------------------------------------------------------------------------------------------------------
$app->post('/api/protectora/enviarEmail/contactoProtectora',function(Request $request, Response $response){

	$emailProtectora = $request->getParam('emailProtectora');
	$emailUsuario = $request->getParam('emailUsuario');
	$asunto = $request->getParam('asunto');
	$telefonoUsuario = $request->getParam('telefonoUsuario');
	$mensaje = $request->getParam('mensaje');
	$nombreUsuario = $request->getParam('nombreUsuario');

	//Datos email de la aplicacion
	$email_user = "adoptame2.0@gmail.com";
	$email_password = "Adoptame20usal";
	//Asunto
	$the_subject = "Contacto usuario";
	
	$address_to = "adoptame2.0@gmail.com";
	$from_name = "Adoptame 2.0";
	$phpmailer = new PHPMailer();
// ---------- datos de la cuenta de Gmail -------------------------------------------------------------
	$phpmailer->Username = $email_user;
	$phpmailer->Password = $email_password; 
//----------------------------------------------------------------------------------------------------
// $phpmailer->SMTPDebug = 1;
	$phpmailer->SMTPSecure = 'ssl';
	$phpmailer->Host = "smtp.gmail.com"; // GMail
	$phpmailer->Port = 465;
	$phpmailer->IsSMTP(); // use SMTP
	$phpmailer->SMTPAuth = true;
	$phpmailer->setFrom($phpmailer->Username,$from_name);
	//Usuario en reply
	$phpmailer->AddReplyTo($emailUsuario, $nombreUsuario);

	$phpmailer->AddAddress($emailProtectora); // recipients email
	$phpmailer->Subject = $asunto;	
	$phpmailer->Body .= "<p>Hola!</p>";
	$phpmailer->Body .= "<p>Tienes una notificación de $nombreUsuario: </p>";
	$phpmailer->Body .= "<p style='color:#3498db;'>$mensaje </p>";
	$phpmailer->Body .= "<p>No olvides contactar de forma privada.</p>";
	$phpmailer->Body .= "<p>Estos son los datos del interesado: </p>";
	$phpmailer->Body .= "<ul><li><p>Nombre: $nombreUsuario </p></li>";
	$phpmailer->Body .= "<li><p>Email: $emailUsuario </p></li>";
	$phpmailer->Body .= "<li><p>Teléfono: $telefonoUsuario</p></ul>";
	$phpmailer->Body .="<h1 style='color:#3498db;'>Adoptame 2.0</h1>";
	$phpmailer->AddEmbeddedImage('../iconos/logo.png', 'logoimg', 'logo.jpg');
	$phpmailer->Body .="<p><img src=\"cid:logoimg\" /></p>";
	$phpmailer->Body .= "<p>Fecha y Hora: ".date("d-m-Y h:i:s")."</p>";
	$phpmailer->IsHTML(true);
	$phpmailer -> charSet = "UTF-8"; 
	
	if(!$phpmailer->Send()){
   		echo "Error en el envio: " . $phpmailer->ErrorInfo;;
	}else{
   		echo "Email enviado";
	}

});
//--------------------------------------------------------------------------------------
// Agregar protectora
//--------------------------------------------------------------------------------------
$app->post('/api/protectora/registrar',function(Request $request, Response $response){

	$idProtectora = $request->getParam('idProtectora');
	$nombre = $request->getParam('nombre');
	$descripcion = $request->getParam('descripcion');
	$email = $request->getParam('email');
	$telefono = $request->getParam('telefono');
	$ciudad = $request->getParam('ciudad');
	
	$consulta = "INSERT INTO protectora (idProtectora, nombre, descripcion, email, telefono, ciudad) VALUES (:idProtectora, :nombre, :descripcion, :email, :telefono, :ciudad)";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idProtectora', $idProtectora);
		$stmt->bindParam(':nombre', $nombre);
		$stmt->bindParam(':descripcion', $descripcion);
		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':telefono', $telefono);
		$stmt->bindParam(':ciudad', $ciudad);
		$stmt->execute();
		echo '{"notice": {"text": "protectora agregada"}';
		
	}catch(PDOException $e){
		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//-------------------------------------------------------------------------
//Obtener los datos de la protectora
//-------------------------------------------------------------------------
$app->get('/api/protectora/detalleProtectora/{idProtectora}',function(Request $request, Response $response){


	$idProtectora = $request->getAttribute('idProtectora');

	//header("Content-Type: application/json; charset=UTF-8");
	$consulta = "SELECT protectora.nombre as nombreProtectora, protectora.ciudad as ciudadProtectora,
						protectora.email as emailProtectora, protectora.telefono as telefonoProtectora,
						protectora.descripcion as descripcionProtectora,
						fotoProtectora.idFotoProtectora as fotoProtectora
				FROM protectora INNER JOIN fotoProtectora ON protectora.idProtectora = fotoProtectora.idProtectora
				WHERE protectora.idProtectora = '$idProtectora'";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$protectora = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($protectora);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});


//----------------------------------------------------------------------------------------------
// Modifica los datos de una protectora
//----------------------------------------------------------------------------------------------
$app->post('/api/protectora/modificarProtectora',function(Request $request, Response $response){

	$idProtectora = $request->getParam('idProtectora');
	$nombre = $request->getParam('nombre');
	$descripcion = $request->getParam('descripcion');
	$email = $request->getParam('email');
	$telefono = $request->getParam('telefono');
	$ciudad = $request->getParam('ciudad');

	$consulta = "UPDATE protectora 
					SET nombre = :nombre, descripcion = :descripcion, email = :email, 
					telefono = :telefono, ciudad = :ciudad
				 WHERE idProtectora = :idProtectora";
	
	try{

		$db = new db();

		//Conexion

		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->bindParam(':idProtectora', $idProtectora);
		$stmt->bindParam(':nombre', $nombre);
		$stmt->bindParam(':descripcion', $descripcion);
		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':telefono', $telefono);
		$stmt->bindParam(':ciudad', $ciudad);
		$stmt->execute();

		echo '{"notice": {"text": "Datos de protectora modificados"}';

	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}
	
});

//--------------------------------------------------------------------------------------
//Subir foto al servidor
//--------------------------------------------------------------------------------------

//$container = $app->getContainer();
//$container['upload_directory'] = __DIR__ . '.uploads';

$app->post('/api/protectora/uploadFoto',function( $request,  $response ,$args){

	//var_dump($_FILES);
	$files = $request->getUploadedFiles();
	//ar_dump($files);
	
    if (empty($files['file'])) {
        throw new Exception('No file has been send');
    }
    $myFile = $files['file'];
    if ($myFile->getError() === UPLOAD_ERR_OK) {
        $uploadFileName = $myFile->getClientFilename();

        $myFile->moveTo('../uploads/' . $uploadFileName);
    }

});

/**
 * Moves the uploaded file to the upload directory and assigns it a unique name
 * to avoid overwriting an existing uploaded file.
 *
 * @param string $directory directory to which the file is moved
 * @param UploadedFile $uploaded file uploaded file to move
 * @return string filename of moved file
 */
function moveUploadedFile($directory, UploadedFile $uploadedFile)
{
    $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
    $basename = bin2hex(random_bytes(8)); // see http://php.net/manual/en/function.random-bytes.php
    $filename = sprintf('%s.%0.8s', $basename, $extension);

    $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $filename);

    return $filename;
}

?>