<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

//-------------------------------------------------------------------------
//Obtener todos los animales
//-------------------------------------------------------------------------
$app->get('/api/animales',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	$consulta = "SELECT * FROM animal WHERE estado != 'adoptado'
					ORDER BY animal.idAnimal DESC";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$animales = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($animales);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//-------------------------------------------------------------------------
//Obtener los datos de los animales para mostrar en menu de adopcion
//
// Mostrara todos los animales menos los que ya estan adoptados
//-------------------------------------------------------------------------
$app->get('/api/animales/menuUsuario',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	
	$consulta = "SELECT animal.idAnimal as idAnimal, animal.nombre as nombre, animal.descripcion as descripcion, 
					animal.estado as estado, fotoanimal.idFoto as idFoto
				FROM animal INNER JOIN fotoanimal ON animal.idAnimal = fotoanimal.idAnimal
				WHERE animal.estado != 'adoptado'
				ORDER BY animal.idAnimal DESC";
	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$animales = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($animales);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//-------------------------------------------------------------------------
//Obtener los detalles de un animal
//-------------------------------------------------------------------------
$app->get('/api/animales/detalleAnimal/{idAnimal}',function(Request $request, Response $response){


	$idAnimal = $request->getAttribute('idAnimal');

	//header("Content-Type: application/json; charset=UTF-8");
	$consulta = "SELECT animal.idProtectora as idProtectora, 
						animal.nombre as nombre, animal.estado as estado,
						animal.descripcion as descripcion, animal.especie as especie,
						animal.tamanio as tamanio, animal.sexo as sexoAnimal,
						animal.apego as apego, animal.obediencia as obediencia,
						animal.comportamiento as comportamiento, animal.actividad as actividad,
						fotoanimal.idFoto as idFoto,
						protectora.nombre as nombreProtectora, protectora.ciudad as ciudadProtectora,
						protectora.email as emailProtectora, protectora.telefono as telefonoProtectora
				FROM animal INNER JOIN fotoanimal ON animal.idAnimal = fotoanimal.idAnimal
							INNER JOIN protectora ON animal.idProtectora = protectora.idProtectora
				WHERE animal.idAnimal = '$idAnimal'";

	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$animal = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($animal);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//-------------------------------------------------------------------------
//Obtener los datos de los animales de una protectora, menos los adoptados
//-------------------------------------------------------------------------
$app->get('/api/animales/menuProtectora/{idProtectora}',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	$idProtectora = $request->getAttribute('idProtectora');

	$consulta = "SELECT animal.idAnimal as idAnimal, animal.nombre as nombre, animal.descripcion as descripcion, 
					animal.estado as estado, fotoanimal.idFoto as idFoto
				FROM animal INNER JOIN fotoanimal ON animal.idAnimal = fotoanimal.idAnimal
				WHERE animal.idProtectora ='$idProtectora'
					  AND animal.estado != 'adoptado'
				ORDER BY animal.idAnimal DESC";
	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$animales = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($animales);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//-------------------------------------------------------------------------
//Obtener los datos de los animales adoptados de una protectora
//-------------------------------------------------------------------------
$app->get('/api/animales/menuProtectora/adoptados/{idProtectora}',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	$idProtectora = $request->getAttribute('idProtectora');

	$consulta = "SELECT animal.idAnimal as idAnimal, animal.nombre as nombre, animal.descripcion as descripcion, 
					animal.estado as estado, fotoanimal.idFoto as idFoto
				FROM animal INNER JOIN fotoanimal ON animal.idAnimal = fotoanimal.idAnimal
				WHERE animal.idProtectora ='$idProtectora'
					  AND animal.estado = 'adoptado'";
	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$animales = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($animales);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//----------------------------------------------------------------------------------------------------
//  Recibe una lista de animales que eliminara de la tabla de animales y fotoanimal.
//		También eliminara el archivo relacionado con el animal
//----------------------------------------------------------------------------------------------------
$app->post('/api/animales/eliminarAnimal',function(Request $request, Response $response){

	$idAnimal = $request->getParam('idAnimal');
	$idArchivo = $request->getParam('idArchivo');

	//Recorre el array de animales que se quiere eliminar

    	
	for ($x=0;$x<count($idAnimal); $x++){
		
		//Sentencias para eliminar a traves del id del animal
    	//Eliminar foto y despues animal
		$consulta = "DELETE FROM fotoanimal WHERE fotoanimal.idAnimal ='$idAnimal[$x]'";
		
		try{

			$db = new db();

			//Conexion
			$db = $db->conectar();
			$ejecutar = $db->query($consulta);
			$fotoEliminada = $ejecutar->fetchAll(PDO::FETCH_OBJ);
			$db = null;

			//Exportar y mostrar JSON
			//echo json_encode($fotoEliminada);

		}catch(PDOException $e){

			echo '{"error": {"text": '.$e->getMessage().'}';
		}

		//Eliminar archivo

		unlink("../uploads/".$idArchivo[$x]);

		//Eliminar animal
    	$consulta = "DELETE FROM animal WHERE animal.idAnimal ='$idAnimal[$x]'";
		
		try{

			$db = new db();

			//Conexion
			$db = $db->conectar();
			$ejecutar = $db->query($consulta);
			$animalEliminado = $ejecutar->fetchAll(PDO::FETCH_OBJ);
			$db = null;

			//Exportar y mostrar JSON
			//echo json_encode($animalEliminado);


		}catch(PDOException $e){

			echo '{"error": {"text": '.$e->getMessage().'}';
		}

	}

});

//------------------------------------------------------------------------------------------
// Marcar animal como adoptado
//------------------------------------------------------------------------------------------
$app->post('/api/animales/marcarAdoptados',function(Request $request, Response $response){

	$idAnimal = $request->getParam('idAnimal');
	$fecha= date("Y-n-j");

	for ($x=0;$x<count($idAnimal); $x++){
		
		//Marcar animal como adoptado
		$consulta = "UPDATE animal SET estado ='adoptado', fecha_adopcion = '$fecha'  
						WHERE idAnimal ='$idAnimal[$x]'";
		
		try{

			$db = new db();

			//Conexion
			$db = $db->conectar();
			$ejecutar = $db->query($consulta);
			$fotoEliminada = $ejecutar->fetchAll(PDO::FETCH_OBJ);
			$db = null;

			//Exportar y mostrar JSON
			//echo json_encode($fotoEliminada);

		}catch(PDOException $e){

			echo '{"error": {"text": '.$e->getMessage().'}';
		}
	}

});

//----------------------------------------------------------------------------------------------------
//Obtener los datos de los animales de la protectora
//
//---------------------------------------------------------------------------------------------------
$app->get('/api/animales/datosProtectora/{idProtectora}',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	$idProtectora = $request->getAttribute('idProtectora');

$consulta = "

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'cachorro'
					AND animal.estado != 'adoptado'
			
			UNION ALL

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'perro'
					AND animal.estado != 'adoptado'

			UNION ALL

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'gato'
					AND animal.estado != 'adoptado'

			UNION ALL

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'roedor'
					AND animal.estado != 'adoptado'

			UNION ALL

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'otros'
					AND animal.estado != 'adoptado'

			";
	
	
	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$datosProtectora = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($datosProtectora);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//----------------------------------------------------------------------------------------------------
//Obtener los datos de los animales adoptados de la protectora
//
//---------------------------------------------------------------------------------------------------
$app->get('/api/animales/datosProtectoraAdoptados/{idProtectora}',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	$idProtectora = $request->getAttribute('idProtectora');

$consulta = "

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'cachorro'
					AND animal.estado = 'adoptado'
			
			UNION ALL

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'perro'
					AND animal.estado = 'adoptado'

			UNION ALL

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'gato'
					AND animal.estado = 'adoptado'

			UNION ALL

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'roedor'
					AND animal.estado = 'adoptado'

			UNION ALL

			SELECT count(animal.idAnimal) as num
				FROM animal 
				WHERE animal.idProtectora ='$idProtectora' AND animal.especie = 'otros'
					AND animal.estado = 'adoptado'

			";
	
	
	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$datosProtectora = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($datosProtectora);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});

//----------------------------------------------------------------------------------------------------
//Obtener los datos de los animales para mostrar en menu de adopcion
//
// Mostrara todos los animales que pasen los filtros indicados menos los que ya estan adoptados
//---------------------------------------------------------------------------------------------------
$app->get('/api/animales/menuUsuario/filtrado/{especie}/{sexo}/{tamanio}/{estado}',function(Request $request, Response $response){

	//header("Content-Type: application/json; charset=UTF-8");
	$especie = $request->getAttribute('especie');
	$sexo = $request->getAttribute('sexo');
	$tamanio = $request->getAttribute('tamanio');
	$estado = $request->getAttribute('estado');

	

	$consulta = "SELECT animal.idAnimal as idAnimal, animal.nombre as nombre, animal.descripcion as descripcion, 
					animal.estado as estado, fotoanimal.idFoto as idFoto
				FROM animal INNER JOIN fotoanimal ON animal.idAnimal = fotoanimal.idAnimal
				WHERE ";
	
	//Estado			
	if ($estado == '*') {
		
		$consulta = $consulta . " animal.estado != 'adoptado'";
	
	}else{

		$consulta = $consulta . " animal.estado = '$estado'";
	}

	//tamanio
	if ($tamanio != '*') 
		$consulta = $consulta . " AND animal.tamanio = '$tamanio'";	

	//sexo
	if ($sexo != '*') 	
		$consulta = $consulta . " AND animal.sexo = '$sexo'";	

	//especie
	if ($especie != '*') 	
		$consulta = $consulta . " AND animal.especie = '$especie'";


	try{

		$db = new db();

		//Conexion
		$db = $db->conectar();
		$ejecutar = $db->query($consulta);
		$animales = $ejecutar->fetchAll(PDO::FETCH_OBJ);
		$db = null;

		//Exportar y mostrar JSON
		echo json_encode($animales);


	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});


//--------------------------------------------------------------------------------------
//Modificar Animal
//--------------------------------------------------------------------------------------
$app->post('/api/animales/modificarAnimal',function( $request,  $response){

	$idAnimal = $request->getParam('idAnimal');
    $especie = $request->getParam('especie');
    $sexo = $request->getParam('sexo');
    $tamanio = $request->getParam('tamanio');
    $estado = $request->getParam('estado');
    $nombre = $request->getParam('nombre');
    $descripcion = $request->getParam('descripcion');
    $apego = $request->getParam('apego');
    $obediencia = $request->getParam('obediencia');
    $comportamiento = $request->getParam('comportamiento');
    $actividad = $request->getParam('actividad');

// idAnimal se rellena solo
	$consulta = "UPDATE animal 
				 SET especie = '$especie', sexo = '$sexo', tamanio = '$tamanio', estado = '$estado',
				 	 nombre = '$nombre' , descripcion = '$descripcion', apego = '$apego', 
				 	 obediencia = '$obediencia', comportamiento = '$comportamiento', actividad = '$actividad'
				 	 
				 WHERE idAnimal ='$idAnimal'";

	try{

		$db = new db();

		//Conexion

		$db = $db->conectar();
		$stmt = $db->prepare($consulta);
		$stmt->execute();
		echo '{"notice": {"text": "Animal modificado"}';
	
	}catch(PDOException $e){

		echo '{"error": {"text": '.$e->getMessage().'}';
	}

});



?>