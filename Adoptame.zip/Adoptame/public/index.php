<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \PHPMailer\PHPMailer\PHPMailer;
use \PHPMailer\PHPMailer\PSMTP;
use \PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';
require '../src/config/db.php';

$app = new \Slim\App;
$app->get('/hello/{name}', function (Request $request, Response $response, array $args) {
    $name = $args['name'];
    $response->getBody()->write("Hello, $name");

    return $response;
});

require '../src/rutas/cliente.php';
require '../src/rutas/protectora.php';
require '../src/rutas/animales.php';

$app->run();

?>